#include <iostream>
#include <string>

using namespace std;

class Osoba
{
public:
    static int liczba_instancji;
    Osoba()
    {
        this -> id = 0;
        this -> imie_osoby = "";
        this -> liczba_instancji++;
    }

    Osoba(int id, string imie_osoby)
    {
        this -> id = id;
        this -> imie_osoby = imie_osoby;
        this -> liczba_instancji++;
    }

    Osoba(Osoba &O)
    {
        this -> id = O.id;
        this -> imie_osoby = O.imie_osoby;
        this -> liczba_instancji++;
    }

    void wypisz_imie_osoby(string argument)
    {
        if(this -> imie_osoby == "")
        {
            cout << "Brak danych!" << endl;
        }
        else
        {
            cout << "Czesc: " << argument << ", mam na imie: " << this ->imie_osoby <<endl;
        }
    }
private:
    int id;
    string imie_osoby;
};
int Osoba::liczba_instancji = 0;

int main()
{
    string imie_osoby = "";
    int id = 0;
    cout << "Podaj id: ";
    cin >> id;
    cout << "Podaj imie: ";
    cin >> imie_osoby;

    cout << "Liczba zarejestrowanych osób to: " << Osoba::liczba_instancji << endl;
    Osoba O1;
    Osoba O2(id, imie_osoby);
    Osoba O3(Osoba &O2);
    O2.wypisz_imie_osoby("Jan");
    return 0;
}
